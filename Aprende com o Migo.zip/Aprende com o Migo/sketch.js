let fail;
let jump;
let snd;
let unicorn;
let uImg;
let tImg;
let bImg;
let trains = [];


function preload() {
   soundFormats('mp3');
  snd = loadSound("audiohub.mp3");
  uImg = loadImage('Pc_Jogo.png');
    tImg = loadImage('objeto0.png');
    tImg = loadImage('objeto1.png');
    tImg = loadImage('objeto2.png');
    tImg = loadImage('objeto3.png');
    tImg = loadImage('objeto4.png');
    tImg = loadImage('objeto5.png');
    tImg = loadImage('objeto6.png');
    tImg = loadImage('objeto7.png');
    tImg = loadImage('objeto8.png');
    tImg = loadImage('objeto9.png');
  bImg = loadImage('fundo_.jpg');
  
}

function setup() {
  createCanvas(800, 450);
  unicorn = new Unicorn(); 
}

function keyPressed() {
  if (key == ' ') {
    unicorn.jump(); //sapo salta
     jump.play();
  }
}

function draw() {
  if (random(1) < 0.005) {
    trains.push(new Train()); //aparecem novos obstáculos
  }

  background(bImg);
  for (let t of trains) {
    t.move();
    t.show();
    if (unicorn.hits(t)) {
      console.log('game over');
      fail.play();
      noLoop();

  }
  }
  unicorn.show();
  unicorn.move();
}

  function mouseClicked() {
  snd.play();
}